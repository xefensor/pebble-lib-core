# Pebble Watchface Core

Shared data and lifecycle code for [Halftone](https://github.com/xefensor/halftone-watchface)
and [Dynamic](https://github.com/xefensor/dynamic-watchface). Version 0.2.0 extends the original
Halftone extraction with richer reading metadata, longer international text and
40px artwork, targeting Emery (Pebble Time 2).

The package is compiled into each watchface's PBW. Users install a watchface;
there is no separate core app or background service to install. A core update
reaches users when a consuming watchface is rebuilt and released.

## Shared responsibilities

- The first two global Pebble complication choices, source subscriptions,
  normalized scalar/image values and bounded receipt caches.
- Music title, artist, playing state and artwork; optional new-notification
  summaries; low phone battery.
- Serialized phone-to-watch messages, v3 packets with strict v1/v2 decoding, freshness and
  expiry, native cache chunks and reconnect/session bookkeeping.
- Notification baselines and privacy clearing. Music/notification content
  stays transient and is not persisted or logged by this core.

Each watchface owns its layout, layers, fonts and generated font metrics,
colors, animations, clock/date presentation, settings form, UUID, permissions
and release files. The core registers no Pebble SDK services or AppMessage
callbacks; the host supplies one dispatcher and forwards relevant events.

This is a bounded two-reading contract, not a general widget framework. The
wire format still contains five bounded records for compatibility. It does not
supply a weather provider, timer integration or playback controls. Source
availability and permissions remain the Pebble phone app's responsibility.

## Version 0.2.0

- Text is bounded to 128 UTF-8 bytes per record, with separate unit and short-label
  fields. Provider-formatted values remain available alongside numeric metadata.
- Optional semantic/source identifiers, numeric value, range and unit let a
  consumer identify battery, humidity, rain and other readings without guessing
  from a percentage string. Missing or invalid metadata is never invented.
- Images can be up to 40×40, 4bpp with a 16-entry palette. Source support still
  determines available artwork detail.
- Version-3 packets are bounded to 5,186 bytes. Hosts should open at least a
  6,144-byte inbox. Decoders still strictly accept legacy versions 1 and 2.
- Native persistent caching retains eight 256-byte keys. Cache compaction strips
  images, preserves value/metadata/receipt/expiry and never renews freshness.
  Restored values carry a native-cache-origin flag, not an observation timestamp.
  Music/notification categories are excluded even when selected as normal readings.
  Legacy native caches without source identity are cleared once during upgrade;
  legacy live packet decoding remains supported.
- Pending complication/context snapshots supersede older waiting snapshots in
  their own channel. Settings and other commands keep FIFO ordering. Superseded
  callbacks receive SUPERSEDED rather than a false acknowledgement.
- Notification bursts are bounded to eight seconds; baseline/session privacy and
  five-second paused-music grace are retained.

Dynamic adopts this version independently. Halftone continues to bundle 0.1.0
until it is rebuilt against a separately checked upgrade. No installed
watchface is changed by updating this repository.

## Use from a watchface

Consumers pin an independently selected release tarball, such as
`vendor/pebble-watchface-core-0.2.0.tgz`, reference it with a `file:` dependency,
and commit `package-lock.json`. `vendor/CORE.json` records the upstream version
and archive checksum. This supports `npm ci` without an npm publishing account
or a dependency on a changing Git branch.

```c
#include <pebble-watchface-core/pebble-watchface-core.h>
```

```js
var core = require('pebble-watchface-core');
var send = core.createMessageQueue(transportOptions);
var complications = core.createComplications(complicationOptions);
var context = core.createContext(contextOptions);
```

Factories receive the host's Pebble API, generated message keys, send function,
clock and timers. The complication factory also receives storage, settings,
optional boolean localization and an optional cache key. The native API stores
its state in a host-owned `WatchfaceCore` and accepts optional storage and
change-notification callbacks.

See [the host contract](docs/HOST-CONTRACT.md) for lifecycle details and the
public [C header](include/pebble-watchface-core.h) / [JS entrypoint](src/js/index.js)
for exact signatures. Halftone and Dynamic are complete consumer examples.

## Build and test

Use a Pebble C SDK with the Emery target, Node.js for the portable JavaScript
suites and a C99 compiler for the native suites. Run these commands from a
checkout of this repository; consumers install the built package instead.

```sh
npm test
pebble build
python3 scripts/package-release.py
```

`pebble build` creates the package's `dist.zip`, containing native code, exported
headers and phone JavaScript. `npm pack` wraps the release package as a versioned
`.tgz`; it does not publish to npm. The release script normalizes SDK ZIP
metadata, writes that tarball to `releases/` and records SHA-256 checksums. `npm test` runs both JavaScript and portable
C suites; `npm run test:native` runs just the latter. Neither needs a watch or
Pebble emulator. Consumer build and rendering results
belong to each watchface's validation record. The initial extraction passed
83 JavaScript tests and three portable C suites; consumer rendering is checked
separately.

## Updating both watchfaces

1. Change the core and run its portable suites, then build the Pebble package.
2. Bump the core version for a new release and create its tarball.
3. Copy that exact tarball into each consumer's `vendor/` directory. Update its
   file dependency, lockfile and `vendor/CORE.json` provenance together.
4. Build and check each consumer. Shared behavior tests cover the engine;
   separate native screenshots check that each layout still fits.
5. Release the new PBWs independently. Existing installed PBWs keep their
   bundled core until the user installs an updated watchface.

For local iteration, Pebble also supports installing a built package from its
local directory. The committed tarball is the reproducible dependency used for
consumer releases.

## License

[PolyForm Noncommercial License 1.0.0](LICENSE), with Xef's required attribution.
Use, modification and sharing are permitted for noncommercial purposes under
that license. Commercial use requires separate permission. This is
source-available software, not an OSI-approved open-source license.
